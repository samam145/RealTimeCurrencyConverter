//import java.io.BufferedReader;
//import java.io.FileWriter;
//import java.io.IOException;
//import java.io.InputStreamReader;
//import java.io.PrintWriter;
import java.io.*;
import java.math.*;
import java.net.*;
import org.json.JSONObject;
import java.text.DecimalFormat;
import java.util.*;
import java.awt.*;

public class CurrencyConverter {

    public static BigDecimal result;
    public static String time;

    public static void main(String[] args) {
        boolean running = true;
        System.out.println("Welcome to the Currency Converter!");

        Scanner sc = new Scanner(System.in);

        while (running) {
            System.out.println();
            System.out.println("Choose an option:");
            System.out.println("1. Convert currency from PKR");
            System.out.println("2. View transaction history");
            System.out.println("3. Exit");

            int option = sc.nextInt();
            sc.nextLine(); // consume newline

            switch (option) {
                case 1:
                    try (PrintWriter out = new PrintWriter(new FileWriter("receipt.txt", true))) {
                        convertCurrencyFromPKR(sc, out);
                    } catch (IOException e) {
                        System.out.println("Error saving receipt to file: " + e.getMessage());
                    }
                    break;
                case 2:
                    viewTransactionHistory();
                    break;
                case 3:
                    running = false;
                    break;
                default:
                    System.out.println("Invalid option. Please choose a valid option.");
                    break;
            }
        }

        System.out.println("Thank you for using the currency converter!");
    }

    public static void convertCurrencyFromPKR(Scanner sc, PrintWriter out) {
        HashMap<Integer, String> currencycodes = new HashMap<>();
        currencycodes.put(1, "USD");
        currencycodes.put(2, "EUR");
        currencycodes.put(3, "AUD");
        currencycodes.put(4, "AED");
        currencycodes.put(5, "CAD");

        System.out.println("Which currency do you want to convert your Pakistani rupees into?");
        System.out.println("1: USD (United States Dollar)");
        System.out.println("2: EUR (Euro)");
        System.out.println("3: AUD (Australian Dollar)");
        System.out.println("4: AED (UAE Dirham)");
        System.out.println("5: CAD (Canadian Dollar)");

        int to = sc.nextInt();
        sc.nextLine(); // consume newline

        if (to < 1 || to > 5) {
            System.out.println("Invalid selection. Please choose a valid option.");
            return;
        }

        String toCode = currencycodes.get(to);

        System.out.println("Enter the amount of Pakistani rupees:");
        double value = sc.nextDouble();
        sc.nextLine(); // consume newline

        if (value < 0) {
            System.out.println("Please enter a positive value!");
            return;
        }

        BigDecimal amount = BigDecimal.valueOf(value);

        try {
            sendHttpGETRequest("PKR", toCode, amount, out);
        } catch (IOException e) {
            System.out.println("Error fetching exchange rate: " + e.getMessage());
        }
    }

    public static void sendHttpGETRequest(String fromCode, String toCode, BigDecimal amount, PrintWriter out) throws IOException {
        DecimalFormat f = new DecimalFormat("0.00");
        String GET_URL = "https://v6.exchangerate-api.com/v6/68ba03b0b6e1c68bf19161bc/pair/" + fromCode + "/" + toCode;
        System.out.println("Requesting URL: " + GET_URL);
        URL url = new URL(GET_URL);
        HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
        httpURLConnection.setRequestMethod("GET");

        int responseCode = httpURLConnection.getResponseCode();
        System.out.println("Response Code: " + responseCode);

        if (responseCode == HttpURLConnection.HTTP_OK) {
            BufferedReader in = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream()));
            String inputLine;
            StringBuilder response = new StringBuilder();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            System.out.println("API Response: " + response.toString()); // Debugging line

            JSONObject obj = new JSONObject(response.toString());
            double exchangeRate = obj.getDouble("conversion_rate");
            time = obj.getString("time_last_update_utc");

            result = amount.multiply(new BigDecimal(exchangeRate));
            System.out.println(f.format(amount) + " " + fromCode + " = " + f.format(result) + " " + toCode);
            System.out.println("Updated as of: " + time + ".");

            out.println("Amount in PKR: " + f.format(amount));
            out.println("Exchange Rate: 1 PKR = " + exchangeRate + " " + toCode);
            out.println("Converted amount in " + toCode + ": " + f.format(result));
            out.println("Updated as of: " + time + ".");
            out.println();

            System.out.println("Transaction saved to receipt.txt");
        } else {
            throw new IOException("HTTP GET request failed with response code: " + responseCode);
        }
    }

    public static void viewTransactionHistory() {
        try {
            Desktop desktop = Desktop.getDesktop();
            desktop.open(new java.io.File("receipt.txt"));
        } catch (IOException e) {
            System.out.println("Error opening transaction history: " + e.getMessage());
        }
    }
}